'use client';
import { useEffect, useMemo, useState } from 'react';
import { useCart } from './CartProvider';
import ProductImage from './ProductImage';
import { taka, toBn, PACK_LABEL } from '@/lib/format';

/* ---------------- PackToggle ---------------- */
function PackToggle({ pack, setPack }) {
  return (
    <div className="pack-toggle" role="tablist" aria-label="প্যাকের ধরন">
      {['combo', 'single'].map((p) => (
        <button key={p} role="tab" aria-selected={pack === p} className={pack === p ? 'active' : ''} onClick={() => setPack(p)}>
          {p === 'combo' ? '🎁 কম্বো প্যাক (ছাড়সহ)' : '🫙 সিঙ্গেল প্যাক'}
        </button>
      ))}
    </div>
  );
}

/* ---------------- ProductCard ---------------- */
function ProductCard({ product, pack, onOpen }) {
  const { add } = useCart();
  const out = product.stock_status === 'out';
  const price = pack === 'combo' ? product.price_combo : product.price_single;
  const saving = product.price_single - product.price_combo;

  return (
    <article className={`card ${out ? 'is-out' : ''}`}>
      <button className="card-media" onClick={() => onOpen(product)} aria-label={`${product.name} বিস্তারিত`}>
        <ProductImage product={product} />
        <div className="badges">
          {(product.badges || []).map((b) => <span key={b} className="tag">{b}</span>)}
          {product.stock_status === 'low' && <span className="tag tag-warn">অল্প বাকি</span>}
          {out && <span className="tag tag-out">স্টক শেষ</span>}
        </div>
      </button>
      <div className="card-body">
        <h3 onClick={() => onOpen(product)}>{product.name}</h3>
        <p className="muted">{product.unit}</p>
        <div className="price-row">
          <strong className="price">{taka(price)}</strong>
          {pack === 'combo' && saving > 0 && (
            <>
              <s className="muted">{taka(product.price_single)}</s>
              <span className="save">{taka(saving)} সাশ্রয়</span>
            </>
          )}
        </div>
        <button className="btn btn-block" disabled={out} onClick={() => add(product, pack, 1)}>
          {out ? 'স্টক নেই' : '+ কার্টে যোগ করুন'}
        </button>
      </div>
    </article>
  );
}

/* ---------------- Product detail modal ---------------- */
function ProductModal({ product, pack: initialPack, onClose }) {
  const { add, setDrawerOpen, settings } = useCart();
  const [qty, setQty] = useState(1);
  const [pack, setPack] = useState(initialPack);

  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  const price = pack === 'combo' ? product.price_combo : product.price_single;
  const out = product.stock_status === 'out';
  const wa = `https://wa.me/${settings.whatsapp_number}?text=${encodeURIComponent(`আসসালামু আলাইকুম, আমি ${product.name} সম্পর্কে জানতে চাই।`)}`;

  return (
    <div className="modal-wrap" onClick={onClose}>
      <div className="modal" role="dialog" aria-modal="true" aria-label={product.name} onClick={(e) => e.stopPropagation()}>
        <button className="icon-btn modal-close" onClick={onClose} aria-label="বন্ধ করুন">✕</button>
        <ProductImage product={product} className="modal-img" />
        <div className="modal-body">
          <h2>{product.name}</h2>
          <p className="muted">{product.category} • {product.unit}</p>
          <div className="nopres">🚫 কোনো প্রিজারভেটিভ নেই</div>
          <p>{product.description}</p>

          {product.ingredients?.length > 0 && (
            <>
              <h4>উপকরণ</h4>
              <div className="chips">{product.ingredients.map((i) => <span key={i} className="chip">{i}</span>)}</div>
            </>
          )}
          <ul className="facts">
            {product.shelf_life && <li>⏳ <strong>শেলফ লাইফ:</strong> {product.shelf_life}</li>}
            {product.storage_note && <li>🧊 <strong>সংরক্ষণ:</strong> {product.storage_note}</li>}
          </ul>

          <PackToggle pack={pack} setPack={setPack} />
          <div className="price-row">
            <strong className="price big">{taka(price * qty)}</strong>
            <span className="muted">({PACK_LABEL[pack]})</span>
          </div>

          <div className="modal-actions">
            <div className="qty qty-lg">
              <button onClick={() => setQty((q) => Math.max(1, q - 1))} aria-label="কমান">−</button>
              <span>{toBn(qty)}</span>
              <button onClick={() => setQty((q) => Math.min(50, q + 1))} aria-label="বাড়ান">+</button>
            </div>
            <button
              className="btn"
              disabled={out}
              onClick={() => {
                add(product, pack, qty);
                onClose();
                setDrawerOpen(true);
              }}
            >
              {out ? 'স্টক নেই' : 'কার্টে যোগ করুন'}
            </button>
          </div>
          {settings.whatsapp_number && (
            <a className="link-btn" href={wa} target="_blank" rel="noopener noreferrer">💬 এই প্রোডাক্ট সম্পর্কে হোয়াটসঅ্যাপে জিজ্ঞাসা করুন</a>
          )}
        </div>
      </div>
    </div>
  );
}

/* ---------------- Why us ---------------- */
function WhyUs({ items }) {
  if (!items?.length) return null;
  return (
    <section className="section alt" id="why-us">
      <div className="container">
        <h2 className="section-title">কেন আমাদের আচার কিনবেন?</h2>
        <div className="why-grid">
          {items.map((w, i) => (
            <div className="why" key={i}>
              <div className="why-icon">{w.icon}</div>
              <h3>{w.title}</h3>
              <p>{w.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Reviews ---------------- */
function Reviews({ reviews }) {
  const [district, setDistrict] = useState('সব');
  const districts = useMemo(() => ['সব', ...new Set(reviews.map((r) => r.district).filter(Boolean))], [reviews]);
  const list = useMemo(() => {
    const l = district === 'সব' ? reviews : reviews.filter((r) => r.district === district);
    return [...l].sort((a, b) => Number(!!b.pinned) - Number(!!a.pinned) || (b.date || '').localeCompare(a.date || ''));
  }, [reviews, district]);
  if (!reviews.length) return null;

  const avg = reviews.reduce((s, r) => s + (r.rating || 0), 0) / reviews.length;

  return (
    <section className="section" id="reviews">
      <div className="container">
        <h2 className="section-title">গ্রাহকরা কী বলছেন</h2>
        <p className="center muted">⭐ গড় রেটিং {toBn(avg.toFixed(1))} / ৫ • {toBn(reviews.length)}টি রিভিউ</p>
        <div className="chips center-chips">
          {districts.map((d) => (
            <button key={d} className={`chip chip-btn ${district === d ? 'on' : ''}`} onClick={() => setDistrict(d)}>{d}</button>
          ))}
        </div>
        <div className="review-grid">
          {list.map((r) => (
            <blockquote className="review" key={r.id}>
              {r.pinned && <span className="pin">📌 সেরা রিভিউ</span>}
              <div className="stars" aria-label={`${r.rating} স্টার`}>{'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}</div>
              <p>{r.text}</p>
              <footer>— <strong>{r.name}</strong>{r.district ? `, ${r.district}` : ''}</footer>
            </blockquote>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Page ---------------- */
export default function Storefront({ products, reviews, settings }) {
  const [pack, setPack] = useState('combo'); // ডিফল্ট কম্বো
  const [open, setOpen] = useState(null);
  const [cat, setCat] = useState('সব');

  const cats = useMemo(() => ['সব', ...new Set(products.map((p) => p.category).filter(Boolean))], [products]);
  const shown = cat === 'সব' ? products : products.filter((p) => p.category === cat);

  return (
    <>
      <section className="hero">
        <div className="container hero-in">
          <div>
            <span className="hero-pill">🚫 প্রিজারভেটিভ-মুক্ত • ১০০% খাঁটি</span>
            <h1>{settings.hero_title}</h1>
            <p>{settings.hero_subtitle}</p>
            <a href="#products" className="btn btn-lg">আচার দেখুন ↓</a>
          </div>
          <div className="hero-art" aria-hidden="true">
            {settings.banner_image_url ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={settings.banner_image_url} alt="" />
            ) : (
              <div className="hero-emoji">🥭🍋🌶️</div>
            )}
          </div>
        </div>
      </section>

      <section className="section" id="products">
        <div className="container">
          <h2 className="section-title">আমাদের আচার</h2>
          <PackToggle pack={pack} setPack={setPack} />
          {cats.length > 2 && (
            <div className="chips center-chips">
              {cats.map((c) => (
                <button key={c} className={`chip chip-btn ${cat === c ? 'on' : ''}`} onClick={() => setCat(c)}>{c}</button>
              ))}
            </div>
          )}
          {shown.length === 0 ? (
            <p className="center muted">এখন কোনো প্রোডাক্ট নেই।</p>
          ) : (
            <div className="grid">
              {shown.map((p) => <ProductCard key={p.id} product={p} pack={pack} onOpen={setOpen} />)}
            </div>
          )}
        </div>
      </section>

      <WhyUs items={settings.why_us} />
      <Reviews reviews={reviews} />

      {open && <ProductModal product={open} pack={pack} onClose={() => setOpen(null)} />}
    </>
  );
}
