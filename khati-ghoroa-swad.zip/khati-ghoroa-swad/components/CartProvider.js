'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

const CartCtx = createContext(null);
export const useCart = () => useContext(CartCtx);

const CART_KEY = 'kgs_cart';
const ORDERS_KEY = 'kgs_orders';

const keyOf = (i) => `${i.product_id}:${i.pack_type}`;

function readJson(key, fallback) {
  try {
    const v = JSON.parse(localStorage.getItem(key));
    return v ?? fallback;
  } catch {
    return fallback;
  }
}

export default function CartProvider({ settings, children }) {
  const [items, setItems] = useState([]);
  const [ready, setReady] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [toast, setToast] = useState('');
  const [bump, setBump] = useState(0);

  useEffect(() => {
    setItems(readJson(CART_KEY, []));
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(CART_KEY, JSON.stringify(items));
    } catch {}
  }, [items, ready]);

  const showToast = useCallback((msg) => {
    setToast(msg);
    setTimeout(() => setToast(''), 2200);
  }, []);

  // একই (product_id + pack_type) থাকলে পরিমাণ বাড়ে; না থাকলে নতুন লাইন
  const add = useCallback(
    (product, pack, qty = 1) => {
      const unit_price = pack === 'combo' ? product.price_combo : product.price_single;
      setItems((prev) => {
        const item = {
          product_id: product.id,
          name: product.name,
          image_url: product.image_url || '',
          emoji: product.emoji || '',
          unit: product.unit || '',
          pack_type: pack,
          unit_price,
          quantity: qty,
        };
        const k = keyOf(item);
        const found = prev.find((i) => keyOf(i) === k);
        if (found) return prev.map((i) => (keyOf(i) === k ? { ...i, quantity: Math.min(50, i.quantity + qty), unit_price } : i));
        return [...prev, item];
      });
      setBump((b) => b + 1);
      showToast('✅ কার্টে যোগ হয়েছে');
    },
    [showToast]
  );

  const setQty = useCallback((k, qty) => {
    setItems((prev) =>
      qty < 1 ? prev.filter((i) => keyOf(i) !== k) : prev.map((i) => (keyOf(i) === k ? { ...i, quantity: Math.min(50, qty) } : i))
    );
  }, []);

  const remove = useCallback((k) => setItems((prev) => prev.filter((i) => keyOf(i) !== k)), []);
  const clear = useCallback(() => setItems([]), []);

  // গ্রাহকের অর্ডার রেফারেন্স ({id, token}) — অ্যাকাউন্ট ছাড়াই ট্র্যাকিং
  const saveOrderRef = useCallback((ref) => {
    const list = readJson(ORDERS_KEY, []);
    localStorage.setItem(ORDERS_KEY, JSON.stringify([ref, ...list].slice(0, 20)));
  }, []);
  const getOrderRefs = useCallback(() => readJson(ORDERS_KEY, []), []);

  const subtotal = useMemo(() => items.reduce((s, i) => s + i.unit_price * i.quantity, 0), [items]);
  const count = useMemo(() => items.reduce((s, i) => s + i.quantity, 0), [items]);

  const value = {
    items, ready, add, setQty, remove, clear, subtotal, count, bump,
    drawerOpen, setDrawerOpen, toast, showToast, saveOrderRef, getOrderRefs, settings, keyOf,
  };
  return <CartCtx.Provider value={value}>{children}</CartCtx.Provider>;
}
