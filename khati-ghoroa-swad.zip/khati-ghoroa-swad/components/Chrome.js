'use client';
import Link from 'next/link';
import { useCart } from './CartProvider';
import { toBn, taka, PACK_LABEL } from '@/lib/format';
import ProductImage from './ProductImage';

export function MarqueeBar() {
  const { settings } = useCart();
  const text = settings.marquee_text;
  if (!text) return null;
  return (
    <div className="marquee" aria-label="ঘোষণা">
      <div className="marquee-track">
        <span>{text}</span>
        <span aria-hidden="true">{text}</span>
        <span aria-hidden="true">{text}</span>
      </div>
    </div>
  );
}

export function Header() {
  const { settings, count, bump, setDrawerOpen } = useCart();
  return (
    <header className="header">
      <div className="container header-row">
        <Link href="/" className="logo">
          <span className="logo-mark">🥭</span>
          <span>{settings.site_name}</span>
        </Link>
        <nav className="header-nav">
          <Link href="/orders">আমার অর্ডার</Link>
          {settings.phone && (
            <a href={`tel:${settings.phone}`} className="header-phone">📞 {toBn(settings.phone)}</a>
          )}
          <button className="cart-btn" onClick={() => setDrawerOpen(true)} aria-label={`কার্ট, ${count}টি আইটেম`}>
            🛒
            {count > 0 && <span key={bump} className="badge bounce">{toBn(count)}</span>}
          </button>
        </nav>
      </div>
    </header>
  );
}

export function Footer() {
  const { settings } = useCart();
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <h3>{settings.site_name}</h3>
          <p>প্রিজারভেটিভ ছাড়া, মায়ের হাতের খাঁটি স্বাদ।</p>
        </div>
        <div>
          <h4>যোগাযোগ</h4>
          {settings.phone && <p>📞 <a href={`tel:${settings.phone}`}>{toBn(settings.phone)}</a></p>}
          {settings.email && <p>✉️ <a href={`mailto:${settings.email}`}>{settings.email}</a></p>}
          {settings.address && <p>📍 {settings.address}</p>}
          {settings.business_hours && <p>🕘 {settings.business_hours}</p>}
        </div>
        <div>
          <h4>লিংক</h4>
          <p><Link href="/">হোম</Link></p>
          <p><Link href="/orders">অর্ডার ট্র্যাক করুন</Link></p>
          <p>💵 পেমেন্ট: ক্যাশ অন ডেলিভারি</p>
        </div>
        {settings.map_embed_url?.startsWith('https://www.google.com/maps/embed') && (
          <div className="footer-map">
            <iframe src={settings.map_embed_url} loading="lazy" title="আমাদের অবস্থান" referrerPolicy="no-referrer-when-downgrade" />
          </div>
        )}
      </div>
      <div className="footer-bottom">© {toBn(new Date().getFullYear())} {settings.site_name}। সর্বস্বত্ব সংরক্ষিত।</div>
    </footer>
  );
}

export function WhatsAppFloat() {
  const { settings } = useCart();
  if (!settings.whatsapp_number) return null;
  const msg = 'আসসালামু আলাইকুম, আমি আপনাদের আচার সম্পর্কে জানতে চাই।';
  return (
    <a
      className="wa-float"
      href={`https://wa.me/${settings.whatsapp_number}?text=${encodeURIComponent(msg)}`}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="হোয়াটসঅ্যাপে মেসেজ করুন"
    >
      <svg viewBox="0 0 32 32" width="28" height="28" fill="currentColor" aria-hidden="true">
        <path d="M16 3C9.4 3 4 8.4 4 15c0 2.3.7 4.5 1.8 6.3L4 29l7.9-1.7A12 12 0 1 0 16 3zm0 21.8c-1.9 0-3.8-.5-5.4-1.5l-.4-.2-4.1.9.9-4-.3-.4A9.8 9.8 0 1 1 16 24.8zm5.4-7.3c-.3-.1-1.8-.9-2-1s-.5-.1-.7.1-.8 1-1 1.2-.4.2-.7.1a8 8 0 0 1-4-3.5c-.3-.5.3-.5.9-1.6.1-.2 0-.4 0-.5l-1-2.3c-.2-.6-.5-.5-.7-.5h-.6a1.2 1.2 0 0 0-.9.4 3.700 3.700 0 0 0-1.100 2.700 6.400 6.400 0 0 0 1.400 3.400 14.600 14.600 0 0 0 5.600 4.900c2 .8 2.800.9 3.800.7a3.200 3.200 0 0 0 2.100-1.500 2.600 2.600 0 0 0 .2-1.500c-.1-.1-.3-.2-.6-.3z" />
      </svg>
    </a>
  );
}

export function Toast() {
  const { toast } = useCart();
  return <div className={`toast ${toast ? 'show' : ''}`} role="status" aria-live="polite">{toast}</div>;
}

export function CartDrawer() {
  const { items, drawerOpen, setDrawerOpen, setQty, remove, subtotal, settings, keyOf } = useCart();

  const waMsg =
    'আসসালামু আলাইকুম, আমি অর্ডার করতে চাই:\n' +
    items.map((i) => `- ${i.name} (${PACK_LABEL[i.pack_type]}) x${i.quantity}`).join('\n') +
    `\nমোট: ${subtotal} টাকা`;

  const remaining = Math.max(0, settings.free_delivery_threshold - subtotal);
  const progress = Math.min(100, (subtotal / (settings.free_delivery_threshold || 1)) * 100);

  return (
    <>
      <div className={`overlay ${drawerOpen ? 'show' : ''}`} onClick={() => setDrawerOpen(false)} />
      <aside className={`drawer ${drawerOpen ? 'open' : ''}`} aria-hidden={!drawerOpen} aria-label="কার্ট">
        <div className="drawer-head">
          <h3>আপনার কার্ট</h3>
          <button className="icon-btn" onClick={() => setDrawerOpen(false)} aria-label="বন্ধ করুন">✕</button>
        </div>

        {items.length === 0 ? (
          <div className="drawer-empty">
            <div style={{ fontSize: 48 }}>🫙</div>
            <p>কার্ট খালি। পছন্দের আচার যোগ করুন!</p>
            <button className="btn" onClick={() => setDrawerOpen(false)}>কেনাকাটা করুন</button>
          </div>
        ) : (
          <>
            <div className="drawer-body">
              {settings.free_delivery_threshold > 0 && (
                <div className="free-ship">
                  {remaining > 0 ? (
                    <p>আর <strong>{taka(remaining)}</strong> কিনলেই ফ্রি ডেলিভারি 🚚</p>
                  ) : (
                    <p>🎉 আপনি ফ্রি ডেলিভারি পাচ্ছেন!</p>
                  )}
                  <div className="bar"><div style={{ width: `${progress}%` }} /></div>
                </div>
              )}
              {items.map((i) => {
                const k = keyOf(i);
                return (
                  <div className="cart-row" key={k}>
                    <ProductImage product={i} className="cart-thumb" />
                    <div className="cart-info">
                      <strong>{i.name}</strong>
                      <small>{PACK_LABEL[i.pack_type]}{i.unit ? ` • ${i.unit}` : ''}</small>
                      <div className="qty">
                        <button onClick={() => setQty(k, i.quantity - 1)} aria-label="কমান">−</button>
                        <span>{toBn(i.quantity)}</span>
                        <button onClick={() => setQty(k, i.quantity + 1)} aria-label="বাড়ান">+</button>
                      </div>
                    </div>
                    <div className="cart-price">
                      <strong>{taka(i.unit_price * i.quantity)}</strong>
                      <button className="link-btn" onClick={() => remove(k)}>মুছুন</button>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="drawer-foot">
              <div className="row"><span>সাবটোটাল</span><strong>{taka(subtotal)}</strong></div>
              <small>ডেলিভারি চার্জ চেকআউটে যোগ হবে</small>
              <Link href="/checkout" className="btn btn-block" onClick={() => setDrawerOpen(false)}>
                অর্ডার কনফার্ম করুন →
              </Link>
              {settings.whatsapp_number && (
                <a
                  className="btn btn-outline btn-block"
                  target="_blank"
                  rel="noopener noreferrer"
                  href={`https://wa.me/${settings.whatsapp_number}?text=${encodeURIComponent(waMsg)}`}
                >
                  হোয়াটসঅ্যাপে অর্ডার করুন
                </a>
              )}
            </div>
          </>
        )}
      </aside>
    </>
  );
}
