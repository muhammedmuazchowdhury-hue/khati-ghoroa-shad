'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { toBn } from '@/lib/format';

const LINKS = [
  ['/admin', 'ড্যাশবোর্ড'],
  ['/admin/orders', 'অর্ডার'],
  ['/admin/products', 'প্রোডাক্ট'],
  ['/admin/reviews', 'রিভিউ'],
  ['/admin/settings', 'সেটিংস'],
];

export default function AdminNav() {
  const path = usePathname();
  const router = useRouter();
  const [newCount, setNewCount] = useState(0);

  useEffect(() => {
    let alive = true;
    async function poll() {
      try {
        const res = await fetch('/api/admin/orders');
        if (!res.ok) return;
        const { orders } = await res.json();
        if (alive) setNewCount(orders.filter((o) => o.status === 'নতুন').length);
      } catch {}
    }
    poll();
    const t = setInterval(poll, 15000); // প্রতি ১৫ সেকেন্ডে নতুন অর্ডার চেক
    return () => { alive = false; clearInterval(t); };
  }, []);

  async function logout() {
    await fetch('/api/admin/logout', { method: 'POST' });
    router.replace('/admin/login');
  }

  return (
    <nav className="admin-bar">
      <strong>🥭 অ্যাডমিন</strong>
      {LINKS.map(([href, label]) => (
        <Link key={href} href={href} className={path === href ? 'on' : ''}>
          {label}
          {href === '/admin/orders' && newCount > 0 && <span className="nbadge">🆕 {toBn(newCount)}</span>}
        </Link>
      ))}
      <Link href="/" target="_blank" className="push">সাইট দেখুন ↗</Link>
      <button onClick={logout}>লগআউট</button>
    </nav>
  );
}
