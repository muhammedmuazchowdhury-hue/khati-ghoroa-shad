/* eslint-disable @next/next/no-img-element */
export default function ProductImage({ product, className = '' }) {
  const emoji = product.emoji || (product.category === 'বালাচাও' ? '🌶️' : '🫙');
  if (product.image_url) {
    return (
      <div className={`pimg ${className}`}>
        <img src={product.image_url} alt={product.name} loading="lazy" />
      </div>
    );
  }
  return (
    <div className={`pimg pimg-fallback ${className}`} role="img" aria-label={product.name}>
      <span>{emoji}</span>
    </div>
  );
}
