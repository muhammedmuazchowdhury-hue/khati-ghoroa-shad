import { NextResponse } from 'next/server';
import { randomBytes } from 'crypto';
import { FieldValue } from 'firebase-admin/firestore';
import { db, isConfigured } from '@/lib/firebaseAdmin';
import { getSettings } from '@/lib/data';
import { allow, clientIp } from '@/lib/rateLimit';
import { validateCheckout, normalizeDigits, calculateDelivery } from '@/lib/validate';

export async function POST(req) {
  if (!isConfigured()) {
    return NextResponse.json({ error: 'Firebase কনফিগার করা হয়নি (.env দেখুন)' }, { status: 503 });
  }
  if (!allow(`order:${clientIp(req)}`, 5, 60 * 60 * 1000)) {
    return NextResponse.json({ error: 'অনেকবার চেষ্টা হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।' }, { status: 429 });
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'ভুল অনুরোধ' }, { status: 400 });
  }

  const customer = {
    name: String(body.name || '').trim().slice(0, 80),
    phone: normalizeDigits(String(body.phone || '')).replace(/\s|-/g, ''),
    address: String(body.address || '').trim().slice(0, 300),
  };
  const errors = validateCheckout(customer);
  if (Object.keys(errors).length) return NextResponse.json({ errors }, { status: 400 });

  const rawItems = Array.isArray(body.items) ? body.items.slice(0, 50) : [];
  if (!rawItems.length) return NextResponse.json({ error: 'কার্ট খালি' }, { status: 400 });

  const firestore = db();
  const settings = await getSettings();

  // দাম সবসময় সার্ভার থেকে নেওয়া হয় — ক্লায়েন্টের পাঠানো দাম বিশ্বাস করা হয় না
  const items = [];
  for (const it of rawItems) {
    const qty = Math.floor(Number(it.quantity));
    const pack = it.pack_type === 'single' ? 'single' : 'combo';
    if (!it.product_id || !(qty >= 1 && qty <= 50)) {
      return NextResponse.json({ error: 'আইটেমে সমস্যা আছে' }, { status: 400 });
    }
    const snap = await firestore.collection('products').doc(String(it.product_id)).get();
    const p = snap.data();
    if (!snap.exists || !p.active) {
      return NextResponse.json({ error: 'একটি প্রোডাক্ট এখন পাওয়া যাচ্ছে না। কার্ট আপডেট করুন।' }, { status: 400 });
    }
    if (p.stock_status === 'out') {
      return NextResponse.json({ error: `"${p.name}" স্টকে নেই` }, { status: 400 });
    }
    items.push({
      product_id: snap.id,
      name: p.name,
      image_url: p.image_url || '',
      pack_type: pack,
      unit_price: pack === 'combo' ? p.price_combo : p.price_single,
      quantity: qty,
    });
  }

  const subtotal = items.reduce((s, i) => s + i.unit_price * i.quantity, 0);
  const delivery_charge = calculateDelivery(customer.address, subtotal, settings);
  const total = subtotal + delivery_charge;

  const year = new Date().getFullYear();
  const counterRef = firestore.collection('counters').doc(`orders-${year}`);
  const track_token = randomBytes(12).toString('hex');

  const order_id = await firestore.runTransaction(async (tx) => {
    const c = await tx.get(counterRef);
    const next = (c.exists ? c.data().value : 0) + 1;
    const id = `KGS-${year}-${String(next).padStart(4, '0')}`;
    tx.set(counterRef, { value: next });
    tx.set(firestore.collection('orders').doc(id), {
      order_id: id,
      track_token,
      customer,
      items,
      subtotal,
      delivery_charge,
      total,
      status: 'নতুন',
      status_history: [{ status: 'নতুন', at: new Date() }],
      note: String(body.note || '').trim().slice(0, 300),
      created_at: FieldValue.serverTimestamp(),
    });
    return id;
  });

  return NextResponse.json({ ok: true, order_id, track_token, total });
}
