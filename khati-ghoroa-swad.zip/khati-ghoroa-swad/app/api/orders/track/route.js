import { NextResponse } from 'next/server';
import { db, isConfigured } from '@/lib/firebaseAdmin';
import { ser } from '@/lib/data';
import { allow, clientIp } from '@/lib/rateLimit';

// গ্রাহকের ব্রাউজারে সেভ করা {order_id, token} দিয়ে অর্ডারের স্ট্যাটাস দেখা।
// টোকেন না মিললে কিছুই ফেরত যায় না, তাই অন্যের অর্ডার দেখা সম্ভব নয়।
export async function POST(req) {
  if (!isConfigured()) return NextResponse.json({ orders: [] });
  if (!allow(`track:${clientIp(req)}`, 60, 10 * 60 * 1000)) {
    return NextResponse.json({ error: 'অনেক বেশি অনুরোধ' }, { status: 429 });
  }
  const { refs } = await req.json().catch(() => ({}));
  if (!Array.isArray(refs)) return NextResponse.json({ orders: [] });

  const out = [];
  for (const r of refs.slice(0, 20)) {
    if (!r?.id || !r?.token) continue;
    const snap = await db().collection('orders').doc(String(r.id)).get();
    if (!snap.exists || snap.data().track_token !== r.token) continue;
    const d = ser(snap.data());
    out.push({
      order_id: d.order_id,
      items: d.items,
      subtotal: d.subtotal,
      delivery_charge: d.delivery_charge,
      total: d.total,
      status: d.status,
      status_history: d.status_history,
      created_at: d.created_at,
    });
  }
  out.sort((a, b) => (b.created_at || 0) - (a.created_at || 0));
  return NextResponse.json({ orders: out });
}
