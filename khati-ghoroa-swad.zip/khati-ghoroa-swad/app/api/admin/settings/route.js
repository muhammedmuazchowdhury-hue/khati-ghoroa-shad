import { NextResponse } from 'next/server';
import { db, bucket, isConfigured } from '@/lib/firebaseAdmin';
import { isAdmin } from '@/lib/auth';
import { getSettings } from '@/lib/data';

const str = (v, max = 500) => String(v ?? '').trim().slice(0, max);
const num = (v) => Math.max(0, Number(v) || 0);

async function guard() {
  if (!(await isAdmin())) return NextResponse.json({ error: 'অনুমতি নেই' }, { status: 401 });
  if (!isConfigured()) return NextResponse.json({ error: 'Firebase কনফিগার করা হয়নি' }, { status: 503 });
  return null;
}

export async function GET() {
  const g = await guard();
  if (g) return g;
  return NextResponse.json({ settings: await getSettings() });
}

export async function PUT(req) {
  const g = await guard();
  if (g) return g;
  const b = await req.json();
  const ref = db().collection('settings').doc('app');
  const old = (await ref.get()).data() || {};

  const data = {
    site_name: str(b.site_name, 80),
    marquee_text: str(b.marquee_text),
    hero_title: str(b.hero_title, 200),
    hero_subtitle: str(b.hero_subtitle, 400),
    whatsapp_number: str(b.whatsapp_number, 20).replace(/\D/g, ''),
    phone: str(b.phone, 20),
    email: str(b.email, 100),
    address: str(b.address, 300),
    map_embed_url: str(b.map_embed_url, 1000),
    business_hours: str(b.business_hours, 150),
    banner_image_url: str(b.banner_image_url, 1000),
    banner_image_path: str(b.banner_image_path, 300),
    why_us: (Array.isArray(b.why_us) ? b.why_us : [])
      .slice(0, 8)
      .map((w) => ({ icon: str(w.icon, 8), title: str(w.title, 80), text: str(w.text, 300) }))
      .filter((w) => w.title),
    free_delivery_threshold: num(b.free_delivery_threshold),
    delivery_charge_dhaka: num(b.delivery_charge_dhaka),
    delivery_charge_outside: num(b.delivery_charge_outside),
  };

  if (old.banner_image_path && old.banner_image_path !== data.banner_image_path) {
    await bucket().file(old.banner_image_path).delete().catch(() => {});
  }
  await ref.set(data, { merge: true });
  return NextResponse.json({ ok: true });
}
