import { NextResponse } from 'next/server';
import { db, isConfigured } from '@/lib/firebaseAdmin';
import { isAdmin } from '@/lib/auth';
import { getReviews } from '@/lib/data';

async function guard() {
  if (!(await isAdmin())) return NextResponse.json({ error: 'অনুমতি নেই' }, { status: 401 });
  if (!isConfigured()) return NextResponse.json({ error: 'Firebase কনফিগার করা হয়নি' }, { status: 503 });
  return null;
}

function clean(b) {
  return {
    name: String(b.name || '').trim().slice(0, 80),
    district: String(b.district || '').trim().slice(0, 40),
    rating: Math.min(5, Math.max(1, Math.round(Number(b.rating) || 5))),
    text: String(b.text || '').trim().slice(0, 600),
    date: String(b.date || new Date().toISOString().slice(0, 10)),
    pinned: !!b.pinned,
    active: b.active !== false,
  };
}

export async function GET() {
  const g = await guard();
  if (g) return g;
  const reviews = await getReviews({ includeInactive: true });
  reviews.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  return NextResponse.json({ reviews });
}

export async function POST(req) {
  const g = await guard();
  if (g) return g;
  const data = clean(await req.json());
  if (!data.name || !data.text) return NextResponse.json({ error: 'নাম ও রিভিউ লিখুন' }, { status: 400 });
  const ref = await db().collection('reviews').add(data);
  return NextResponse.json({ ok: true, id: ref.id });
}

export async function PUT(req) {
  const g = await guard();
  if (g) return g;
  const body = await req.json();
  if (!body.id) return NextResponse.json({ error: 'id দিন' }, { status: 400 });
  await db().collection('reviews').doc(body.id).update(clean(body));
  return NextResponse.json({ ok: true });
}

export async function DELETE(req) {
  const g = await guard();
  if (g) return g;
  const id = new URL(req.url).searchParams.get('id');
  if (!id) return NextResponse.json({ error: 'id দিন' }, { status: 400 });
  await db().collection('reviews').doc(id).delete();
  return NextResponse.json({ ok: true });
}
