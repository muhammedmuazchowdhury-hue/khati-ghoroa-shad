import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { timingSafeEqual } from 'crypto';
import { db, isConfigured } from '@/lib/firebaseAdmin';
import { createSession, SESSION_COOKIE } from '@/lib/auth';
import { allow, clientIp } from '@/lib/rateLimit';

export async function POST(req) {
  const ip = clientIp(req);
  if (!allow(`login:${ip}`, 5, 15 * 60 * 1000)) {
    return NextResponse.json({ error: 'অনেকবার ভুল হয়েছে। ১৫ মিনিট পর আবার চেষ্টা করুন।' }, { status: 429 });
  }
  const { password } = await req.json().catch(() => ({}));
  if (!password) return NextResponse.json({ error: 'পাসওয়ার্ড দিন' }, { status: 400 });

  let ok = false;
  if (isConfigured()) {
    const snap = await db().collection('admin').doc('config').get();
    if (snap.exists) ok = await bcrypt.compare(String(password), snap.data().password_hash);
  }
  // সিড ছাড়াই চলার জন্য: ADMIN_PASSWORD এনভায়রনমেন্ট ভেরিয়েবল দিয়েও ঢোকা যায়
  // (admin/config-এ hash থাকলে সেটাও কাজ করবে)
  const envPw = process.env.ADMIN_PASSWORD;
  if (!ok && envPw && envPw.length >= 8) {
    const a = Buffer.from(String(password));
    const b = Buffer.from(envPw);
    ok = a.length === b.length && timingSafeEqual(a, b);
  }
  if (!ok) return NextResponse.json({ error: 'ভুল পাসওয়ার্ড' }, { status: 401 });

  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE, await createSession(), {
    httpOnly: true,
    sameSite: 'strict',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 60 * 60 * 24 * 7,
  });
  return res;
}
