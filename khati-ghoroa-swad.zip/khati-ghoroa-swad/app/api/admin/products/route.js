import { NextResponse } from 'next/server';
import { FieldValue } from 'firebase-admin/firestore';
import { db, bucket, isConfigured } from '@/lib/firebaseAdmin';
import { isAdmin } from '@/lib/auth';
import { getProducts } from '@/lib/data';

const num = (v) => Math.max(0, Number(v) || 0);

function clean(b) {
  return {
    name: String(b.name || '').trim(),
    slug: String(b.slug || '').trim(),
    description: String(b.description || '').trim(),
    ingredients: Array.isArray(b.ingredients) ? b.ingredients.map((s) => String(s).trim()).filter(Boolean) : [],
    shelf_life: String(b.shelf_life || '').trim(),
    storage_note: String(b.storage_note || '').trim(),
    image_url: String(b.image_url || ''),
    image_path: String(b.image_path || ''),
    price_single: num(b.price_single),
    price_combo: num(b.price_combo),
    unit: String(b.unit || '').trim(),
    category: String(b.category || 'আচার').trim(),
    badges: Array.isArray(b.badges) ? b.badges.map((s) => String(s).trim()).filter(Boolean) : [],
    stock_status: ['in_stock', 'low', 'out'].includes(b.stock_status) ? b.stock_status : 'in_stock',
    active: b.active !== false,
    sort_order: num(b.sort_order) || 999,
  };
}

async function guard() {
  if (!(await isAdmin())) return NextResponse.json({ error: 'অনুমতি নেই' }, { status: 401 });
  if (!isConfigured()) return NextResponse.json({ error: 'Firebase কনফিগার করা হয়নি' }, { status: 503 });
  return null;
}

export async function GET() {
  const g = await guard();
  if (g) return g;
  return NextResponse.json({ products: await getProducts({ includeInactive: true }) });
}

export async function POST(req) {
  const g = await guard();
  if (g) return g;
  const data = clean(await req.json());
  if (!data.name || !data.price_single || !data.price_combo) {
    return NextResponse.json({ error: 'নাম ও দুই ধরনের দাম আবশ্যক' }, { status: 400 });
  }
  const ref = await db().collection('products').add({
    ...data,
    created_at: FieldValue.serverTimestamp(),
    updated_at: FieldValue.serverTimestamp(),
  });
  return NextResponse.json({ ok: true, id: ref.id });
}

export async function PUT(req) {
  const g = await guard();
  if (g) return g;
  const body = await req.json();
  if (!body.id) return NextResponse.json({ error: 'id দিন' }, { status: 400 });
  const ref = db().collection('products').doc(body.id);
  const old = await ref.get();
  if (!old.exists) return NextResponse.json({ error: 'প্রোডাক্ট পাওয়া যায়নি' }, { status: 404 });

  const data = clean({ ...old.data(), ...body });
  // ছবি বদলালে পুরনো ছবি Storage থেকে মুছে ফেলা
  const oldPath = old.data().image_path;
  if (oldPath && oldPath !== data.image_path) {
    await bucket().file(oldPath).delete().catch(() => {});
  }
  await ref.update({ ...data, updated_at: FieldValue.serverTimestamp() });
  return NextResponse.json({ ok: true });
}

// ডিলিট = সফট ডিলিট (active=false)। পুরনো অর্ডারের স্ন্যাপশট অক্ষত থাকে।
export async function DELETE(req) {
  const g = await guard();
  if (g) return g;
  const id = new URL(req.url).searchParams.get('id');
  if (!id) return NextResponse.json({ error: 'id দিন' }, { status: 400 });
  await db().collection('products').doc(id).update({ active: false, updated_at: FieldValue.serverTimestamp() });
  return NextResponse.json({ ok: true });
}
