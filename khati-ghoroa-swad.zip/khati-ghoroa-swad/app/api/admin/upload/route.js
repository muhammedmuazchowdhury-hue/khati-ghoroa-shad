import { NextResponse } from 'next/server';
import { randomUUID } from 'crypto';
import { bucket, isConfigured } from '@/lib/firebaseAdmin';
import { isAdmin } from '@/lib/auth';

const ALLOWED = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };
const MAX = 4 * 1024 * 1024; // ৪ MB

export async function POST(req) {
  if (!(await isAdmin())) return NextResponse.json({ error: 'অনুমতি নেই' }, { status: 401 });
  if (!isConfigured()) return NextResponse.json({ error: 'Firebase কনফিগার করা হয়নি' }, { status: 503 });

  const form = await req.formData();
  const file = form.get('file');
  const folder = form.get('folder') === 'banner' ? 'banner' : 'products';
  if (!file || typeof file === 'string') return NextResponse.json({ error: 'ফাইল দিন' }, { status: 400 });

  const ext = ALLOWED[file.type];
  if (!ext) return NextResponse.json({ error: 'শুধু JPG, PNG বা WebP ছবি দিন' }, { status: 400 });
  if (file.size > MAX) return NextResponse.json({ error: 'ছবি ৪MB-এর বেশি হতে পারবে না' }, { status: 400 });

  const path = `${folder}/${Date.now()}-${randomUUID().slice(0, 8)}.${ext}`;
  const token = randomUUID();
  const buf = Buffer.from(await file.arrayBuffer());
  const b = bucket();
  await b.file(path).save(buf, {
    contentType: file.type,
    metadata: {
      cacheControl: 'public, max-age=31536000',
      metadata: { firebaseStorageDownloadTokens: token },
    },
  });
  const url = `https://firebasestorage.googleapis.com/v0/b/${b.name}/o/${encodeURIComponent(path)}?alt=media&token=${token}`;
  return NextResponse.json({ ok: true, url, path });
}
