import { NextResponse } from 'next/server';
import { FieldValue } from 'firebase-admin/firestore';
import { db, isConfigured } from '@/lib/firebaseAdmin';
import { isAdmin } from '@/lib/auth';
import { docToObj } from '@/lib/data';
import { TRANSITIONS } from '@/lib/validate';

async function guard() {
  if (!(await isAdmin())) return NextResponse.json({ error: 'অনুমতি নেই' }, { status: 401 });
  if (!isConfigured()) return NextResponse.json({ error: 'Firebase কনফিগার করা হয়নি' }, { status: 503 });
  return null;
}

export async function GET() {
  const g = await guard();
  if (g) return g;
  const snap = await db().collection('orders').orderBy('created_at', 'desc').limit(300).get();
  const orders = snap.docs.map((d) => {
    const { track_token, ...rest } = docToObj(d);
    return rest;
  });
  return NextResponse.json({ orders });
}

export async function PATCH(req) {
  const g = await guard();
  if (g) return g;
  const { id, status } = await req.json();
  const ref = db().collection('orders').doc(String(id));

  const result = await db().runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) return { code: 404, error: 'অর্ডার পাওয়া যায়নি' };
    const current = snap.data().status;
    if (!(TRANSITIONS[current] || []).includes(status)) {
      return { code: 400, error: `"${current}" থেকে "${status}"-এ যাওয়া যায় না` };
    }
    tx.update(ref, {
      status,
      // arrayUnion-এ serverTimestamp চলে না, তাই ক্লায়েন্ট টাইম ব্যবহার
      status_history: FieldValue.arrayUnion({ status, at: new Date() }),
    });
    return { code: 200 };
  });

  if (result.code !== 200) return NextResponse.json({ error: result.error }, { status: result.code });
  return NextResponse.json({ ok: true });
}
