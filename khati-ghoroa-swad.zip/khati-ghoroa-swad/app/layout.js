import { Hind_Siliguri } from 'next/font/google';
import './globals.css';
import { getSettings } from '@/lib/data';

const font = Hind_Siliguri({ subsets: ['bengali', 'latin'], weight: ['400', '500', '600', '700'], display: 'swap' });

export const dynamic = 'force-dynamic';

export async function generateMetadata() {
  const s = await getSettings();
  return {
    title: `${s.site_name} — প্রিজারভেটিভ-মুক্ত খাঁটি আচার`,
    description: 'কোনো প্রিজারভেটিভ ছাড়া, মায়ের হাতের স্বাদের খাঁটি ঘরোয়া আচার। সারা বাংলাদেশে ক্যাশ অন ডেলিভারি।',
  };
}

export const viewport = { width: 'device-width', initialScale: 1, themeColor: '#2f5d3a' };

export default function RootLayout({ children }) {
  return (
    <html lang="bn">
      <body className={font.className}>{children}</body>
    </html>
  );
}
