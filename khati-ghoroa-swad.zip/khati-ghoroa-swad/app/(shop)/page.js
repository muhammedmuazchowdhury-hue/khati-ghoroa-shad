import Storefront from '@/components/Storefront';
import { getProducts, getReviews, getSettings } from '@/lib/data';

export const dynamic = 'force-dynamic';

export default async function Home() {
  const [products, reviews, settings] = await Promise.all([getProducts(), getReviews(), getSettings()]);
  return <Storefront products={products} reviews={reviews} settings={settings} />;
}
