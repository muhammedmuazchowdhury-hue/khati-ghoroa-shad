'use client';
import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { useCart } from '@/components/CartProvider';
import { taka, toBn, bnDate, PACK_LABEL } from '@/lib/format';

const STEPS = [
  { s: 'নতুন', icon: '🟢' },
  { s: 'কনফার্মড', icon: '🟡' },
  { s: 'প্যাকিং', icon: '🟠' },
  { s: 'ডেলিভারিতে', icon: '🔵' },
  { s: 'সম্পন্ন', icon: '✅' },
];

function Tracker({ order }) {
  if (order.status === 'বাতিল') return <div className="alert">❌ এই অর্ডারটি বাতিল করা হয়েছে।</div>;
  const idx = STEPS.findIndex((x) => x.s === order.status);
  return (
    <ol className="tracker">
      {STEPS.map((x, i) => {
        const at = order.status_history?.find((h) => h.status === x.s)?.at;
        return (
          <li key={x.s} className={i <= idx ? 'done' : ''}>
            <span className="dot">{i <= idx ? x.icon : '○'}</span>
            <span className="lbl">{x.s}</span>
            {at && <small className="muted">{bnDate(at)}</small>}
          </li>
        );
      })}
    </ol>
  );
}

export default function OrdersPage() {
  const { getOrderRefs, ready } = useCart();
  const [orders, setOrders] = useState(null);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const refs = getOrderRefs();
    if (!refs.length) return setOrders([]);
    try {
      const res = await fetch('/api/orders/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refs }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setOrders(data.orders);
      setError('');
    } catch (e) {
      setError(e.message || 'লোড করা যায়নি');
      setOrders((o) => o ?? []);
    }
  }, [getOrderRefs]);

  useEffect(() => {
    if (!ready) return;
    load();
    const t = setInterval(load, 20000); // প্রতি ২০ সেকেন্ডে স্ট্যাটাস রিফ্রেশ
    return () => clearInterval(t);
  }, [ready, load]);

  return (
    <div className="container page">
      <h1 className="page-title">আমার অর্ডার</h1>
      {error && <div className="alert">{error}</div>}
      {orders === null && <p className="center muted">লোড হচ্ছে…</p>}
      {orders?.length === 0 && (
        <div className="center">
          <div style={{ fontSize: 56 }}>📦</div>
          <p>এই ডিভাইসে কোনো অর্ডার পাওয়া যায়নি।</p>
          <Link href="/" className="btn">কেনাকাটা শুরু করুন</Link>
        </div>
      )}
      {orders?.map((o) => (
        <section className="panel order" key={o.order_id}>
          <div className="order-head">
            <div>
              <strong>{toBn(o.order_id)}</strong>
              <small className="muted"> • {bnDate(o.created_at)}</small>
            </div>
            <span className={`status s-${o.status}`}>{o.status}</span>
          </div>
          <Tracker order={o} />
          <div className="order-items">
            {o.items.map((i, k) => (
              <div className="sum-row" key={k}>
                <span>{i.name} <small className="muted">({PACK_LABEL[i.pack_type]}) × {toBn(i.quantity)}</small></span>
                <span>{taka(i.unit_price * i.quantity)}</span>
              </div>
            ))}
            <div className="sum-row"><span>ডেলিভারি</span><span>{o.delivery_charge ? taka(o.delivery_charge) : 'ফ্রি'}</span></div>
            <div className="sum-row total"><span>মোট (ক্যাশ অন ডেলিভারি)</span><span>{taka(o.total)}</span></div>
          </div>
        </section>
      ))}
    </div>
  );
}
