import CartProvider from '@/components/CartProvider';
import { MarqueeBar, Header, Footer, WhatsAppFloat, Toast, CartDrawer } from '@/components/Chrome';
import { getSettings } from '@/lib/data';

export const dynamic = 'force-dynamic';

export default async function ShopLayout({ children }) {
  const settings = await getSettings();
  return (
    <CartProvider settings={settings}>
      <MarqueeBar />
      <Header />
      <main>{children}</main>
      <Footer />
      <CartDrawer />
      <WhatsAppFloat />
      <Toast />
    </CartProvider>
  );
}
