import Link from 'next/link';
import { toBn } from '@/lib/format';

export default async function Success({ searchParams }) {
  const { id } = await searchParams;
  return (
    <div className="container page center success">
      <div style={{ fontSize: 64 }}>🎉</div>
      <h1>ধন্যবাদ! আপনার অর্ডার গ্রহণ করা হয়েছে</h1>
      {id && (
        <p className="order-id">অর্ডার আইডি: <strong>{toBn(id)}</strong></p>
      )}
      <p>অর্ডার কনফার্ম করতে আমরা শীঘ্রই আপনাকে ফোন করব। অনুগ্রহ করে ফোন ধরার জন্য প্রস্তুত থাকুন।</p>
      <div className="row-gap">
        <Link href="/orders" className="btn">অর্ডার ট্র্যাক করুন</Link>
        <Link href="/" className="btn btn-outline">আরও কেনাকাটা</Link>
      </div>
    </div>
  );
}
