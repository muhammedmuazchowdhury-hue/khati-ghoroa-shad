'use client';
import { useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useCart } from '@/components/CartProvider';
import { validateCheckout, calculateDelivery } from '@/lib/validate';
import { taka, toBn, PACK_LABEL } from '@/lib/format';

export default function CheckoutPage() {
  const router = useRouter();
  const { items, ready, subtotal, settings, clear, saveOrderRef } = useCart();
  const [form, setForm] = useState({ name: '', phone: '', address: '', note: '' });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const [serverError, setServerError] = useState('');

  const delivery = useMemo(() => calculateDelivery(form.address, subtotal, settings), [form.address, subtotal, settings]);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function submit(e) {
    e.preventDefault();
    setServerError('');
    const errs = validateCheckout(form);
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setBusy(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          items: items.map(({ product_id, pack_type, quantity }) => ({ product_id, pack_type, quantity })),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (data.errors) setErrors(data.errors);
        setServerError(data.error || '');
        setBusy(false);
        return;
      }
      saveOrderRef({ id: data.order_id, token: data.track_token });
      clear();
      router.push(`/checkout/success?id=${encodeURIComponent(data.order_id)}`);
    } catch {
      setServerError('নেটওয়ার্ক সমস্যা। আবার চেষ্টা করুন।');
      setBusy(false);
    }
  }

  if (!ready) return <div className="container page"><p className="center muted">লোড হচ্ছে…</p></div>;
  if (!items.length)
    return (
      <div className="container page center">
        <div style={{ fontSize: 56 }}>🛒</div>
        <h2>আপনার কার্ট খালি</h2>
        <Link href="/#products" className="btn">আচার দেখুন</Link>
      </div>
    );

  return (
    <div className="container page">
      <h1 className="page-title">অর্ডার কনফার্ম করুন</h1>
      <div className="checkout-grid">
        <form onSubmit={submit} noValidate className="panel">
          <h3>ডেলিভারির তথ্য</h3>
          <label>
            আপনার নাম
            <input value={form.name} onChange={set('name')} autoComplete="name" placeholder="যেমন: রহিমা বেগম" aria-invalid={!!errors.name} />
            {errors.name && <span className="err">{errors.name}</span>}
          </label>
          <label>
            মোবাইল নম্বর
            <input value={form.phone} onChange={set('phone')} inputMode="tel" autoComplete="tel" placeholder="01XXXXXXXXX" aria-invalid={!!errors.phone} />
            {errors.phone && <span className="err">{errors.phone}</span>}
          </label>
          <label>
            সম্পূর্ণ ঠিকানা
            <textarea rows={3} value={form.address} onChange={set('address')} autoComplete="street-address" placeholder="বাসা/গ্রাম, রোড, থানা, জেলা" aria-invalid={!!errors.address} />
            {errors.address && <span className="err">{errors.address}</span>}
          </label>
          <label>
            বিশেষ নির্দেশনা <small className="muted">(ঐচ্ছিক)</small>
            <input value={form.note} onChange={set('note')} />
          </label>
          {serverError && <div className="alert">{serverError}</div>}
          <button className="btn btn-block btn-lg" disabled={busy}>{busy ? 'অর্ডার হচ্ছে…' : `অর্ডার নিশ্চিত করুন • ${taka(subtotal + delivery)}`}</button>
          <p className="muted center small">💵 পেমেন্ট: ক্যাশ অন ডেলিভারি — পণ্য হাতে পেয়ে টাকা দিন।</p>
        </form>

        <aside className="panel summary">
          <h3>অর্ডার সামারি</h3>
          {items.map((i) => (
            <div className="sum-row" key={`${i.product_id}:${i.pack_type}`}>
              <span>{i.name} <small className="muted">({PACK_LABEL[i.pack_type]}) × {toBn(i.quantity)}</small></span>
              <span>{taka(i.unit_price * i.quantity)}</span>
            </div>
          ))}
          <hr />
          <div className="sum-row"><span>সাবটোটাল</span><span>{taka(subtotal)}</span></div>
          <div className="sum-row"><span>ডেলিভারি চার্জ</span><span>{delivery === 0 ? 'ফ্রি 🎉' : taka(delivery)}</span></div>
          <div className="sum-row total"><span>মোট</span><span>{taka(subtotal + delivery)}</span></div>
          <small className="muted">ঠিকানায় “ঢাকা” থাকলে ঢাকার চার্জ প্রযোজ্য। চূড়ান্ত দাম সার্ভার থেকে নিশ্চিত হবে।</small>
        </aside>
      </div>
    </div>
  );
}
