'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { api } from '@/components/admin/api';
import { taka, toBn, bnDate } from '@/lib/format';

export default function Dashboard() {
  const [orders, setOrders] = useState(null);
  const [products, setProducts] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    let alive = true;
    async function load() {
      try {
        const [o, p] = await Promise.all([api('/api/admin/orders'), api('/api/admin/products')]);
        if (!alive) return;
        setOrders(o.orders);
        setProducts(p.products);
        setError('');
      } catch (e) {
        if (alive) { setError(e.message); setOrders((x) => x ?? []); }
      }
    }
    load();
    const t = setInterval(load, 15000);
    return () => { alive = false; clearInterval(t); };
  }, []);

  if (!orders) return <p className="muted">লোড হচ্ছে…</p>;

  // ঢাকার সময়ের "আজ"
  const dayKey = (ms) => new Date(ms).toLocaleDateString('en-CA', { timeZone: 'Asia/Dhaka' });
  const today = dayKey(Date.now());
  const todays = orders.filter((o) => o.created_at && dayKey(o.created_at) === today);
  const countable = (o) => o.status !== 'বাতিল';
  const revenueToday = todays.filter(countable).reduce((s, o) => s + o.total, 0);
  const delivered = orders.filter((o) => o.status === 'সম্পন্ন').reduce((s, o) => s + o.total, 0);
  const fresh = orders.filter((o) => o.status === 'নতুন');
  const lowStock = products.filter((p) => p.active && p.stock_status !== 'in_stock');

  return (
    <>
      <h1>ড্যাশবোর্ড</h1>
      {error && <div className="alert">{error}</div>}
      <div className="stats">
        <div className="stat"><span>আজকের অর্ডার</span><b>{toBn(todays.length)}</b></div>
        <div className="stat"><span>আজকের রেভিনিউ</span><b>{taka(revenueToday)}</b></div>
        <div className="stat"><span>🆕 নতুন অর্ডার</span><b style={{ color: fresh.length ? 'var(--chili)' : undefined }}>{toBn(fresh.length)}</b></div>
        <div className="stat"><span>সম্পন্ন অর্ডারের মোট</span><b>{taka(delivered)}</b></div>
      </div>

      {lowStock.length > 0 && (
        <div className="alert">
          ⚠️ স্টক সতর্কতা: {lowStock.map((p) => `${p.name} (${p.stock_status === 'out' ? 'শেষ' : 'অল্প'})`).join(', ')}
        </div>
      )}

      <div className="toolbar"><h2 style={{ margin: 0 }}>সাম্প্রতিক অর্ডার</h2><Link href="/admin/orders" className="btn btn-outline btn-sm">সব দেখুন</Link></div>
      <div className="table-wrap">
        <table>
          <thead><tr><th>আইডি</th><th>গ্রাহক</th><th>মোট</th><th>স্ট্যাটাস</th><th>সময়</th></tr></thead>
          <tbody>
            {orders.slice(0, 8).map((o) => (
              <tr key={o.id}>
                <td>{toBn(o.order_id)}</td>
                <td>{o.customer.name}<br /><small className="muted">{toBn(o.customer.phone)}</small></td>
                <td>{taka(o.total)}</td>
                <td><span className={`status s-${o.status}`}>{o.status}</span></td>
                <td><small>{bnDate(o.created_at)}</small></td>
              </tr>
            ))}
            {orders.length === 0 && <tr><td colSpan={5} className="center muted">এখনো কোনো অর্ডার নেই</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}
