'use client';
/* eslint-disable @next/next/no-img-element */
import { useEffect, useState } from 'react';
import { api, uploadImage } from '@/components/admin/api';

export default function AdminSettings() {
  const [s, setS] = useState(null);
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api('/api/admin/settings').then((d) => setS(d.settings)).catch((e) => setError(e.message));
  }, []);

  if (!s) return error ? <div className="alert">{error}</div> : <p className="muted">লোড হচ্ছে…</p>;

  const set = (k) => (e) => setS((x) => ({ ...x, [k]: e.target.value }));
  const setWhy = (i, k, v) => setS((x) => ({ ...x, why_us: x.why_us.map((w, j) => (j === i ? { ...w, [k]: v } : w)) }));

  async function onBanner(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const { url, path } = await uploadImage(file, 'banner');
      setS((x) => ({ ...x, banner_image_url: url, banner_image_path: path }));
    } catch (err) { setError(err.message); }
  }

  async function save(e) {
    e.preventDefault();
    setBusy(true); setMsg(''); setError('');
    try {
      await api('/api/admin/settings', { method: 'PUT', body: s });
      setMsg('✅ সেটিংস সেভ হয়েছে');
    } catch (err) { setError(err.message); }
    setBusy(false);
  }

  return (
    <form onSubmit={save}>
      <div className="toolbar"><h1>সেটিংস</h1><button className="btn" disabled={busy}>{busy ? 'সেভ হচ্ছে…' : 'সব সেভ করুন'}</button></div>
      {msg && <div className="ok">{msg}</div>}
      {error && <div className="alert">{error}</div>}

      <section className="panel" style={{ marginBottom: 16 }}>
        <h2>হোমপেজ</h2>
        <label>সাইটের নাম<input value={s.site_name || ''} onChange={set('site_name')} /></label>
        <label>চলমান ঘোষণা (মার্কি)<input value={s.marquee_text || ''} onChange={set('marquee_text')} /></label>
        <label>হিরো শিরোনাম<input value={s.hero_title || ''} onChange={set('hero_title')} /></label>
        <label>হিরো উপশিরোনাম<textarea rows={2} value={s.hero_subtitle || ''} onChange={set('hero_subtitle')} /></label>
        <div>
          <strong>ব্যানার ছবি</strong><br />
          {s.banner_image_url && <img src={s.banner_image_url} alt="" style={{ maxHeight: 120, borderRadius: 10, margin: '6px 0' }} />}
          <input type="file" accept="image/jpeg,image/png,image/webp" onChange={onBanner} />
          {s.banner_image_url && (
            <button type="button" className="link-btn" onClick={() => setS((x) => ({ ...x, banner_image_url: '', banner_image_path: '' }))}>ছবি সরান</button>
          )}
        </div>
      </section>

      <section className="panel" style={{ marginBottom: 16 }}>
        <h2>যোগাযোগ</h2>
        <div className="form-grid">
          <label>ফোন<input value={s.phone || ''} onChange={set('phone')} /></label>
          <label>হোয়াটসঅ্যাপ নম্বর <small className="muted">(দেশের কোডসহ: 8801XXXXXXXXX)</small><input value={s.whatsapp_number || ''} onChange={set('whatsapp_number')} /></label>
          <label>ইমেইল<input value={s.email || ''} onChange={set('email')} /></label>
          <label>ব্যবসার সময়<input value={s.business_hours || ''} onChange={set('business_hours')} /></label>
          <label className="full">ঠিকানা<input value={s.address || ''} onChange={set('address')} /></label>
          <label className="full">গুগল ম্যাপ Embed URL <small className="muted">(https://www.google.com/maps/embed?… দিয়ে শুরু)</small><input value={s.map_embed_url || ''} onChange={set('map_embed_url')} /></label>
        </div>
      </section>

      <section className="panel" style={{ marginBottom: 16 }}>
        <h2>ডেলিভারি</h2>
        <div className="form-grid">
          <label>ঢাকার ডেলিভারি চার্জ (৳)<input type="number" min="0" value={s.delivery_charge_dhaka ?? 0} onChange={set('delivery_charge_dhaka')} /></label>
          <label>ঢাকার বাইরে (৳)<input type="number" min="0" value={s.delivery_charge_outside ?? 0} onChange={set('delivery_charge_outside')} /></label>
          <label>ফ্রি ডেলিভারি থ্রেশহোল্ড (৳)<input type="number" min="0" value={s.free_delivery_threshold ?? 0} onChange={set('free_delivery_threshold')} /></label>
        </div>
      </section>

      <section className="panel">
        <div className="toolbar">
          <h2 style={{ margin: '0 auto 0 0' }}>“কেন কিনবেন” সেকশন</h2>
          <button type="button" className="btn btn-outline btn-sm" onClick={() => setS((x) => ({ ...x, why_us: [...(x.why_us || []), { icon: '✨', title: '', text: '' }] }))}>+ যোগ করুন</button>
        </div>
        {(s.why_us || []).map((w, i) => (
          <div key={i} className="form-grid" style={{ borderTop: '1px dashed var(--line)', paddingTop: 10 }}>
            <label>আইকন (ইমোজি)<input value={w.icon} onChange={(e) => setWhy(i, 'icon', e.target.value)} /></label>
            <label>শিরোনাম<input value={w.title} onChange={(e) => setWhy(i, 'title', e.target.value)} /></label>
            <label className="full">বিবরণ<textarea rows={2} value={w.text} onChange={(e) => setWhy(i, 'text', e.target.value)} /></label>
            <button type="button" className="link-btn" onClick={() => setS((x) => ({ ...x, why_us: x.why_us.filter((_, j) => j !== i) }))}>এই আইটেম মুছুন</button>
          </div>
        ))}
      </section>
    </form>
  );
}
