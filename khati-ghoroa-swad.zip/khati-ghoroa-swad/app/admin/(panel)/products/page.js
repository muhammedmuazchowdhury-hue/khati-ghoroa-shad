'use client';
/* eslint-disable @next/next/no-img-element */
import { useEffect, useState } from 'react';
import { api, uploadImage } from '@/components/admin/api';
import { taka } from '@/lib/format';

const EMPTY = {
  name: '', slug: '', description: '', ingredientsText: '', shelf_life: '', storage_note: '',
  image_url: '', image_path: '', price_single: '', price_combo: '', unit: '', category: 'আচার',
  badgesText: '', stock_status: 'in_stock', active: true, sort_order: 100,
};

const toForm = (p) => ({ ...EMPTY, ...p, ingredientsText: (p.ingredients || []).join(', '), badgesText: (p.badges || []).join(', ') });
const splitList = (s) => s.split(/[,،]/).map((x) => x.trim()).filter(Boolean);

function ProductForm({ initial, onSaved, onCancel }) {
  const [f, setF] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [upBusy, setUpBusy] = useState(false);
  const [error, setError] = useState('');
  const set = (k) => (e) => setF((x) => ({ ...x, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }));

  async function onFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUpBusy(true);
    setError('');
    try {
      const { url, path } = await uploadImage(file, 'products');
      setF((x) => ({ ...x, image_url: url, image_path: path }));
    } catch (err) {
      setError(err.message);
    }
    setUpBusy(false);
  }

  async function save(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    const { ingredientsText, badgesText, ...rest } = f;
    const body = { ...rest, ingredients: splitList(ingredientsText), badges: splitList(badgesText) };
    try {
      await api('/api/admin/products', { method: f.id ? 'PUT' : 'POST', body });
      onSaved();
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  }

  return (
    <form className="panel" onSubmit={save} style={{ marginBottom: 20 }}>
      <h2>{f.id ? 'প্রোডাক্ট এডিট' : 'নতুন প্রোডাক্ট'}</h2>
      <div className="form-grid">
        <label>নাম *<input value={f.name} onChange={set('name')} required /></label>
        <label>ক্যাটাগরি<input value={f.category} onChange={set('category')} placeholder="আচার / বালাচাও" /></label>
        <label>সিঙ্গেল প্যাকের দাম (৳) *<input type="number" min="0" value={f.price_single} onChange={set('price_single')} required /></label>
        <label>কম্বো প্যাকের দাম (৳) *<input type="number" min="0" value={f.price_combo} onChange={set('price_combo')} required /></label>
        <label>পরিমাণ<input value={f.unit} onChange={set('unit')} placeholder="৫০০ গ্রাম" /></label>
        <label>শেলফ লাইফ<input value={f.shelf_life} onChange={set('shelf_life')} placeholder="৬ মাস" /></label>
        <label className="full">বিবরণ<textarea rows={3} value={f.description} onChange={set('description')} /></label>
        <label className="full">উপকরণ <small className="muted">(কমা দিয়ে আলাদা করুন)</small><input value={f.ingredientsText} onChange={set('ingredientsText')} placeholder="আম, সরিষার তেল, লবণ" /></label>
        <label className="full">সংরক্ষণ নির্দেশনা<input value={f.storage_note} onChange={set('storage_note')} /></label>
        <label>ব্যাজ <small className="muted">(কমা দিয়ে)</small><input value={f.badgesText} onChange={set('badgesText')} placeholder="বেস্ট সেলার, নতুন" /></label>
        <label>স্টক
          <select value={f.stock_status} onChange={set('stock_status')}>
            <option value="in_stock">স্টকে আছে</option>
            <option value="low">অল্প বাকি</option>
            <option value="out">স্টক শেষ</option>
          </select>
        </label>
        <label>সাজানোর ক্রম <small className="muted">(ছোট আগে)</small><input type="number" value={f.sort_order} onChange={set('sort_order')} /></label>
        <label style={{ alignSelf: 'end' }}><input type="checkbox" checked={f.active} onChange={set('active')} /> সাইটে দেখান</label>
        <div className="full" style={{ marginBottom: 14 }}>
          <strong style={{ display: 'block', marginBottom: 6 }}>ছবি</strong>
          {f.image_url && <img src={f.image_url} alt="" className="thumb" style={{ width: 120, height: 90, marginBottom: 8 }} />}
          <input type="file" accept="image/jpeg,image/png,image/webp" onChange={onFile} />
          <small className="muted">JPG/PNG/WebP, সর্বোচ্চ ৪MB।{upBusy && ' আপলোড হচ্ছে…'}</small>
        </div>
      </div>
      {error && <div className="alert">{error}</div>}
      <div className="toolbar">
        <button className="btn" disabled={busy || upBusy}>{busy ? 'সেভ হচ্ছে…' : 'সেভ করুন'}</button>
        <button type="button" className="btn btn-outline" onClick={onCancel}>বাতিল</button>
      </div>
    </form>
  );
}

export default function AdminProducts() {
  const [products, setProducts] = useState(null);
  const [editing, setEditing] = useState(null);
  const [error, setError] = useState('');

  async function load() {
    try {
      setProducts((await api('/api/admin/products')).products);
    } catch (e) {
      setError(e.message);
      setProducts([]);
    }
  }
  useEffect(() => { load(); }, []);

  async function toggleActive(p) {
    try {
      await api('/api/admin/products', { method: 'PUT', body: { id: p.id, active: !p.active } });
      load();
    } catch (e) { setError(e.message); }
  }

  if (!products) return <p className="muted">লোড হচ্ছে…</p>;

  return (
    <>
      <div className="toolbar">
        <h1>প্রোডাক্ট</h1>
        <button className="btn" onClick={() => setEditing(EMPTY)}>+ নতুন প্রোডাক্ট</button>
      </div>
      {error && <div className="alert">{error}</div>}
      {editing && (
        <ProductForm
          key={editing.id || 'new'}
          initial={editing}
          onCancel={() => setEditing(null)}
          onSaved={() => { setEditing(null); load(); }}
        />
      )}
      <div className="table-wrap">
        <table>
          <thead><tr><th>ছবি</th><th>নাম</th><th>সিঙ্গেল</th><th>কম্বো</th><th>স্টক</th><th>স্ট্যাটাস</th><th /></tr></thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id} style={{ opacity: p.active ? 1 : 0.55 }}>
                <td>{p.image_url ? <img className="thumb" src={p.image_url} alt="" /> : <span className="thumb">🫙</span>}</td>
                <td><strong>{p.name}</strong><br /><small className="muted">{p.category} • {p.unit}</small></td>
                <td>{taka(p.price_single)}</td>
                <td>{taka(p.price_combo)}</td>
                <td>{{ in_stock: 'আছে', low: 'অল্প', out: 'শেষ' }[p.stock_status]}</td>
                <td>{p.active ? '✅ লাইভ' : '🚫 লুকানো'}</td>
                <td style={{ whiteSpace: 'nowrap' }}>
                  <button className="btn btn-sm btn-outline" onClick={() => { setEditing(toForm(p)); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>এডিট</button>{' '}
                  <button className="btn btn-sm btn-outline" onClick={() => toggleActive(p)}>{p.active ? 'লুকান' : 'দেখান'}</button>
                </td>
              </tr>
            ))}
            {products.length === 0 && <tr><td colSpan={7} className="center muted">কোনো প্রোডাক্ট নেই। “নতুন প্রোডাক্ট” চাপুন।</td></tr>}
          </tbody>
        </table>
      </div>
      <p className="muted small">দাম বদলালে পুরনো অর্ডারের দাম অপরিবর্তিত থাকে (অর্ডারে দাম স্ন্যাপশট হিসেবে সেভ হয়)।</p>
    </>
  );
}
