import AdminNav from '@/components/admin/AdminNav';

export const metadata = { title: 'অ্যাডমিন প্যানেল', robots: { index: false, follow: false } };

export default function PanelLayout({ children }) {
  return (
    <div className="admin-shell">
      <AdminNav />
      <div className="admin-main">{children}</div>
    </div>
  );
}
