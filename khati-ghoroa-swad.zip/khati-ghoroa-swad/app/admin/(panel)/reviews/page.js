'use client';
import { useEffect, useState } from 'react';
import { api } from '@/components/admin/api';

const blank = () => ({ name: '', district: '', rating: 5, text: '', date: new Date().toISOString().slice(0, 10), pinned: false, active: true });

export default function AdminReviews() {
  const [reviews, setReviews] = useState(null);
  const [f, setF] = useState(null);
  const [error, setError] = useState('');

  async function load() {
    try { setReviews((await api('/api/admin/reviews')).reviews); }
    catch (e) { setError(e.message); setReviews([]); }
  }
  useEffect(() => { load(); }, []);

  const set = (k) => (e) => setF((x) => ({ ...x, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }));

  async function save(e) {
    e.preventDefault();
    setError('');
    try {
      await api('/api/admin/reviews', { method: f.id ? 'PUT' : 'POST', body: f });
      setF(null);
      load();
    } catch (err) { setError(err.message); }
  }

  async function patch(r, changes) {
    try { await api('/api/admin/reviews', { method: 'PUT', body: { ...r, ...changes } }); load(); }
    catch (e) { setError(e.message); }
  }

  async function del(r) {
    if (!confirm(`“${r.name}”-এর রিভিউ মুছবেন?`)) return;
    try { await api(`/api/admin/reviews?id=${r.id}`, { method: 'DELETE' }); load(); }
    catch (e) { setError(e.message); }
  }

  if (!reviews) return <p className="muted">লোড হচ্ছে…</p>;

  return (
    <>
      <div className="toolbar"><h1>রিভিউ</h1><button className="btn" onClick={() => setF(blank())}>+ নতুন রিভিউ</button></div>
      {error && <div className="alert">{error}</div>}

      {f && (
        <form className="panel" onSubmit={save} style={{ marginBottom: 16 }}>
          <div className="form-grid">
            <label>গ্রাহকের নাম *<input value={f.name} onChange={set('name')} required /></label>
            <label>জেলা<input value={f.district} onChange={set('district')} placeholder="ঢাকা" /></label>
            <label>রেটিং
              <select value={f.rating} onChange={set('rating')}>{[5, 4, 3, 2, 1].map((n) => <option key={n} value={n}>{'★'.repeat(n)}</option>)}</select>
            </label>
            <label>তারিখ<input type="date" value={f.date} onChange={set('date')} /></label>
            <label className="full">রিভিউ *<textarea rows={3} value={f.text} onChange={set('text')} required /></label>
            <label><input type="checkbox" checked={f.pinned} onChange={set('pinned')} /> 📌 পিন করুন (সবার উপরে)</label>
            <label><input type="checkbox" checked={f.active} onChange={set('active')} /> সাইটে দেখান</label>
          </div>
          <div className="toolbar">
            <button className="btn">সেভ</button>
            <button type="button" className="btn btn-outline" onClick={() => setF(null)}>বাতিল</button>
          </div>
        </form>
      )}

      <div className="table-wrap">
        <table>
          <thead><tr><th>গ্রাহক</th><th>রিভিউ</th><th>অবস্থা</th><th /></tr></thead>
          <tbody>
            {reviews.map((r) => (
              <tr key={r.id} style={{ opacity: r.active ? 1 : 0.55 }}>
                <td><strong>{r.name}</strong><br /><small className="muted">{r.district} • {r.date}</small><br /><span className="stars">{'★'.repeat(r.rating)}</span></td>
                <td style={{ maxWidth: 380 }}>{r.text}</td>
                <td>{r.pinned && '📌 '}{r.active ? '✅' : '🚫'}</td>
                <td style={{ whiteSpace: 'nowrap' }}>
                  <button className="btn btn-sm btn-outline" onClick={() => patch(r, { pinned: !r.pinned })}>{r.pinned ? 'আনপিন' : 'পিন'}</button>{' '}
                  <button className="btn btn-sm btn-outline" onClick={() => { setF({ ...r }); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>এডিট</button>{' '}
                  <button className="btn btn-sm btn-danger" onClick={() => del(r)}>মুছুন</button>
                </td>
              </tr>
            ))}
            {reviews.length === 0 && <tr><td colSpan={4} className="center muted">কোনো রিভিউ নেই</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}
