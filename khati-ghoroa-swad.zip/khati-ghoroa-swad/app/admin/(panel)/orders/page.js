'use client';
import { useCallback, useEffect, useState } from 'react';
import { api } from '@/components/admin/api';
import { taka, toBn, bnDate, PACK_LABEL } from '@/lib/format';
import { STATUSES, TRANSITIONS } from '@/lib/validate';

export default function AdminOrders() {
  const [orders, setOrders] = useState(null);
  const [filter, setFilter] = useState('সব');
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState('');

  const load = useCallback(async () => {
    try {
      const { orders } = await api('/api/admin/orders');
      setOrders(orders);
    } catch (e) {
      setError(e.message);
      setOrders((o) => o ?? []);
    }
  }, []);

  useEffect(() => {
    load();
    const t = setInterval(load, 15000);
    return () => clearInterval(t);
  }, [load]);

  async function changeStatus(o, status) {
    if (status === 'বাতিল' && !confirm('অর্ডারটি বাতিল করবেন? এটি আর বদলানো যাবে না।')) return;
    setBusyId(o.id);
    setError('');
    try {
      await api('/api/admin/orders', { method: 'PATCH', body: { id: o.id, status } });
      await load();
    } catch (e) {
      setError(e.message);
    }
    setBusyId('');
  }

  if (!orders) return <p className="muted">লোড হচ্ছে…</p>;

  // নতুন অর্ডার সবার উপরে
  const list = orders
    .filter((o) => filter === 'সব' || o.status === filter)
    .sort((a, b) => Number(b.status === 'নতুন') - Number(a.status === 'নতুন') || (b.created_at || 0) - (a.created_at || 0));

  return (
    <>
      <div className="toolbar">
        <h1>অর্ডার</h1>
        <select value={filter} onChange={(e) => setFilter(e.target.value)} style={{ width: 'auto', marginTop: 0 }}>
          {['সব', ...STATUSES].map((s) => <option key={s}>{s}</option>)}
        </select>
        <button className="btn btn-outline btn-sm" onClick={load}>🔄 রিফ্রেশ</button>
      </div>
      {error && <div className="alert">{error}</div>}
      {list.length === 0 && <p className="muted center">কোনো অর্ডার নেই।</p>}

      {list.map((o) => (
        <details key={o.id} className={`order-card ${o.status === 'নতুন' ? 'is-new' : ''}`} open={o.status === 'নতুন'}>
          <summary>
            <strong>{toBn(o.order_id)}</strong>
            <span className={`status s-${o.status}`}>{o.status}</span>
            <span>{o.customer.name}</span>
            <span className="muted">{taka(o.total)}</span>
            <small className="muted" style={{ marginLeft: 'auto' }}>{bnDate(o.created_at)}</small>
          </summary>

          <div className="detail print-area">
            <p style={{ marginTop: 12 }}>
              <strong>{o.customer.name}</strong> • <a href={`tel:${o.customer.phone}`}>📞 {toBn(o.customer.phone)}</a><br />
              📍 {o.customer.address}
              {o.note && <><br />📝 <em>{o.note}</em></>}
            </p>
            <div className="table-wrap">
              <table>
                <tbody>
                  {o.items.map((i, k) => (
                    <tr key={k}>
                      <td>{i.name} <small className="muted">({PACK_LABEL[i.pack_type]})</small></td>
                      <td>{toBn(i.quantity)} × {taka(i.unit_price)}</td>
                      <td style={{ textAlign: 'right' }}>{taka(i.quantity * i.unit_price)}</td>
                    </tr>
                  ))}
                  <tr><td colSpan={2}>ডেলিভারি চার্জ</td><td style={{ textAlign: 'right' }}>{taka(o.delivery_charge)}</td></tr>
                  <tr><td colSpan={2}><strong>মোট (ক্যাশ অন ডেলিভারি)</strong></td><td style={{ textAlign: 'right' }}><strong>{taka(o.total)}</strong></td></tr>
                </tbody>
              </table>
            </div>

            <div className="toolbar" style={{ marginTop: 12 }}>
              <a className="btn btn-sm" href={`tel:${o.customer.phone}`}>📞 কল করুন</a>
              <button className="btn btn-outline btn-sm" onClick={() => window.print()}>🖨️ প্রিন্ট</button>
              <span style={{ marginLeft: 'auto' }} />
              {(TRANSITIONS[o.status] || []).length === 0 ? (
                <small className="muted">এই স্ট্যাটাস আর বদলানো যাবে না</small>
              ) : (
                TRANSITIONS[o.status].map((s) => (
                  <button
                    key={s}
                    disabled={busyId === o.id}
                    className={`btn btn-sm ${s === 'বাতিল' ? 'btn-danger' : ''}`}
                    onClick={() => changeStatus(o, s)}
                  >
                    {s === 'বাতিল' ? '✕ বাতিল' : `→ ${s}`}
                  </button>
                ))
              )}
            </div>

            <small className="muted">
              ইতিহাস: {o.status_history?.map((h) => `${h.status} (${bnDate(h.at)})`).join(' → ')}
            </small>
          </div>
        </details>
      ))}
    </>
  );
}
