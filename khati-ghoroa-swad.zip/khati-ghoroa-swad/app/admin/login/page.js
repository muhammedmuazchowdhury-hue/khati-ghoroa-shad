'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function AdminLogin() {
  const router = useRouter();
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    const res = await fetch('/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password }),
    });
    const data = await res.json().catch(() => ({}));
    if (res.ok) {
      router.replace('/admin');
      router.refresh();
    } else {
      setError(data.error || 'লগইন ব্যর্থ');
      setBusy(false);
    }
  }

  return (
    <div className="admin-shell">
      <form className="panel login-box" onSubmit={submit}>
        <h2 className="center">🔐 অ্যাডমিন লগইন</h2>
        <label>
          পাসওয়ার্ড
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoFocus autoComplete="current-password" />
        </label>
        {error && <div className="alert">{error}</div>}
        <button className="btn btn-block" disabled={busy || !password}>{busy ? 'যাচাই হচ্ছে…' : 'ঢুকুন'}</button>
      </form>
    </div>
  );
}
