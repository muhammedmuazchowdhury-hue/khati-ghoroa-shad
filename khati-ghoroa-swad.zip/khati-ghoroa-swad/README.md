# খাটি ঘরোয়া স্বাদ — আচারের ই-কমার্স (Next.js + Firebase)

গেস্ট-চেকআউট, শুধু ক্যাশ অন ডেলিভারি, কোনো ইউজার অ্যাকাউন্ট নেই। মূল বার্তা: **প্রিজারভেটিভ-মুক্ত**।

## চালানোর ধাপ

```bash
npm install
cp .env.example .env.local     # মানগুলো বসান (নিচে দেখুন)
npm run seed                   # নমুনা প্রোডাক্ট, রিভিউ, সেটিংস ও অ্যাডমিন পাসওয়ার্ড ঢোকাবে
npm run dev                    # http://localhost:3000
```

> `npm run seed` কাজ না করলে (পুরনো Node): `node --env-file=.env.local scripts/seed.mjs` (Node 20.6+ লাগবে)।

অ্যাডমিন: `http://localhost:3000/admin` — পাসওয়ার্ড = `.env.local`-এর `ADMIN_PASSWORD`।

> Firebase সেট না করেই `npm run dev` চালালে সাইট **ডেমো ডেটা** দিয়ে চলবে (দেখার জন্য), কিন্তু অর্ডার ও অ্যাডমিন কাজ করবে না।

## Firebase সেটআপ
1. console.firebase.google.com → নতুন প্রজেক্ট
2. **Firestore Database** তৈরি করুন (Production mode) ও **Storage** চালু করুন
3. Project settings → Service accounts → **Generate new private key** → JSON থেকে মানগুলো `.env.local`-এ
4. `firestore.rules` ও `storage.rules` Firebase Console-এ পেস্ট করুন (সব ক্লায়েন্ট অ্যাক্সেস বন্ধ; সার্ভার Admin SDK দিয়ে কাজ করে)

## আর্কিটেকচারের সিদ্ধান্ত (ব্লুপ্রিন্ট থেকে যা বদলেছে)
- **ক্লায়েন্ট থেকে সরাসরি Firestore নয়** — সব রিড/রাইট Next.js API/সার্ভার কম্পোনেন্ট দিয়ে। তাই ফোন/ঠিকানা ফাঁসের ঝুঁকি নেই।
- **দাম সার্ভারে হিসাব হয়** — ব্রাউজার থেকে পাঠানো দাম বিশ্বাস করা হয় না।
- **অর্ডার ট্র্যাকিং**: অর্ডারের সাথে র‍্যান্ডম টোকেন তৈরি হয়, গ্রাহকের ব্রাউজারে `{id, token}` সেভ থাকে। ID অনুমান করে অন্যের অর্ডার দেখা যায় না।
- **অর্ডার আইডি** `KGS-বছর-NNNN` — Firestore transaction কাউন্টারে, ডুপ্লিকেট হয় না।
- **রিয়েল-টাইম** → অ্যাডমিন ও গ্রাহক পেজ ১৫–২০ সেকেন্ড পরপর পোল করে (Firebase client SDK ছাড়া নিরাপদ রাখার জন্য)।
- **অ্যাডমিন লগইন**: bcrypt hash (`admin/config`) + HttpOnly/SameSite=Strict JWT কুকি + middleware গার্ড।

## জানা সীমাবদ্ধতা
- রেট লিমিট ইন-মেমোরি — Vercel-এর সার্ভারলেসে প্রতি ইনস্ট্যান্সে আলাদা। ট্রাফিক বাড়লে Upstash Redis ব্যবহার করুন।
- স্টক কমানো নেই; অ্যাডমিন হাতে `স্টক শেষ` সেট করে।
- ছবি অপ্টিমাইজেশন: আপলোডের আগে WebP/কম সাইজে দেওয়া ভালো (সীমা ৪MB)।

## Vercel ডিপ্লয়
GitHub-এ পুশ → Vercel-এ Import → Environment Variables-এ `.env.example`-এর সব কী বসান (`FIREBASE_PRIVATE_KEY` ডাবল কোটসহ, `\n` রেখে) → Deploy।

## ফোল্ডার
```
app/(shop)/      গ্রাহক সাইট (হোম, চেকআউট, অর্ডারস)
app/admin/       অ্যাডমিন প্যানেল
app/api/         অর্ডার ও অ্যাডমিন API
components/      UI কম্পোনেন্ট
lib/             Firebase, auth, validation, ডেটা
scripts/seed.mjs নমুনা ডেটা ঢোকানো
```
