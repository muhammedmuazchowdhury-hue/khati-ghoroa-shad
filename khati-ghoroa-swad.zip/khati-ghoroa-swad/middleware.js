import { NextResponse } from 'next/server';
import { verifyToken, SESSION_COOKIE } from '@/lib/session';

export async function middleware(req) {
  const { pathname } = req.nextUrl;
  const isLogin = pathname === '/admin/login';
  const ok = await verifyToken(req.cookies.get(SESSION_COOKIE)?.value);

  if (!ok && !isLogin) {
    const url = req.nextUrl.clone();
    url.pathname = '/admin/login';
    return NextResponse.redirect(url);
  }
  if (ok && isLogin) {
    const url = req.nextUrl.clone();
    url.pathname = '/admin';
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

// /api/admin/* রুটগুলো নিজেরাই isAdmin() চেক করে
export const config = { matcher: ['/admin/:path*'] };
