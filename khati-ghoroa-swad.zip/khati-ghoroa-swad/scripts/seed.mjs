// ব্যবহার: cp .env.example .env.local  (মান বসান)  →  npm run seed
// Node 20.6+ এ: node --env-file=.env.local scripts/seed.mjs
import bcrypt from 'bcryptjs';
import { initializeApp, cert } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { defaultSettings, sampleProducts, sampleReviews } from '../lib/seedData.mjs';

const { FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY, ADMIN_PASSWORD } = process.env;
if (!FIREBASE_PROJECT_ID || !FIREBASE_CLIENT_EMAIL || !FIREBASE_PRIVATE_KEY || !ADMIN_PASSWORD) {
  console.error('❌ .env.local-এ FIREBASE_* ও ADMIN_PASSWORD সেট করুন, তারপর: node --env-file=.env.local scripts/seed.mjs');
  process.exit(1);
}

initializeApp({
  credential: cert({
    projectId: FIREBASE_PROJECT_ID,
    clientEmail: FIREBASE_CLIENT_EMAIL,
    privateKey: FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
  }),
});
const db = getFirestore();

// settings
await db.collection('settings').doc('app').set(defaultSettings, { merge: true });
console.log('✅ settings/app');

// admin password (bcrypt hash)
await db.collection('admin').doc('config').set({
  password_hash: await bcrypt.hash(ADMIN_PASSWORD, 10),
  updated_at: FieldValue.serverTimestamp(),
});
console.log('✅ admin/config (পাসওয়ার্ড hash করে সেভ হয়েছে)');

// products — slug দিয়ে ডকুমেন্ট আইডি, তাই আবার চালালে ডুপ্লিকেট হবে না
for (const { emoji, ...p } of sampleProducts) {
  await db.collection('products').doc(p.slug).set(
    { ...p, image_url: '', images: [], stock_status: 'in_stock', active: true, created_at: FieldValue.serverTimestamp(), updated_at: FieldValue.serverTimestamp() },
    { merge: true }
  );
}
console.log(`✅ ${sampleProducts.length}টি প্রোডাক্ট`);

for (const [i, r] of sampleReviews.entries()) {
  await db.collection('reviews').doc(`seed-${i + 1}`).set({ ...r, active: true }, { merge: true });
}
console.log(`✅ ${sampleReviews.length}টি রিভিউ`);
console.log('\n🎉 সিড সম্পন্ন। এখন npm run dev চালান, /admin/login-এ ঢুকুন।');
